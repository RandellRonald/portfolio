export const profile = {
 name:'Randell Ronald', email:'randellronald5@gmail.com', phone:'8075548419',
 github:'https://github.com/RandellRonald', linkedin:'https://www.linkedin.com/in/randell-ronald-60492336b/',
};
export const skills=[{name:'Languages',items:['Python','JavaScript','HTML','CSS']},{name:'Frontend',items:['React']},{name:'Platforms',items:['Firebase']},{name:'Tools',items:['Git','GitHub']}];
export const projects=[
 {name:'SmartLand',category:'LOCATION INTELLIGENCE',image:'/images/smartland.png',alt:'SmartLand location analysis interface with map and environmental context',description:'Location intelligence for Kochi, turning geographic coordinates into explainable environmental risk and livability context.',details:['Deterministic spatial analysis','Location validation and flood indicators'],tech:['Python','FastAPI','JavaScript','Leaflet','GeoJSON'],url:'https://github.com/RandellRonald/Smartland'},
 {name:'AutoBlueprint',category:'CONSTRAINT-BASED DESIGN',image:'/images/autoblueprint.png',alt:'AutoBlueprint interface showing a generated 3D residential model',description:'A residential planning system that translates geometric constraints into 2D blueprints and 3D models.',details:['Backend-validated room editing','SVG generation and export support'],tech:['Python','FastAPI','Shapely','React','Three.js','SQLite'],url:'https://github.com/RandellRonald/AutoBlueprint'},
 {name:'AutoKey3D',category:'PARAMETRIC GEOMETRY',image:'/images/autokey3d.png',alt:'AutoKey3D generated key model and interactive preview interface',description:'A web-based tool for generating parametric 3D key models, with interactive previews and downloadable STL files.',details:['SHA256-based uniqueness mechanism','CadQuery geometry and WebGL preview'],tech:['Python','FastAPI','CadQuery','JavaScript','WebGL'],url:'https://github.com/RandellRonald/AutoKey3D'}
];
